# VCOO Onboarding & Template Readiness Plan

> **For Hermes:** Use subagent-driven-development skill to implement this plan task-by-task.

**Goal:** Ensure VCOO onboarding flow and template are fully tested, documented, and ready for distribution to customers.

**Assumptions:**  
- Repository root: `/home/ubuntu/versus/`  
- Onboarding code: `/home/ubuntu/versus/vcoo-onboarding/`  
- Template code: `/home/ubuntu/versus/vcoo-template/`  
- Multipass is installed and functional for VM testing.  
- Vercel onboarding endpoint is accessible at `https://onboard.vcoo.dev` (or similar).  

**Approach:**  
1. Validate onboarding endpoint responsiveness and basic flow.  
2. Run full template test suite (phases 0‑8) to confirm template integrity.  
3. Test the end‑to‑end installation script (`install.sh`) in a clean Ubuntu 22.04 VM via multipass.  
4. Update documentation (README, SOUL.md, release notes) with any findings.  
5. Bump version tags and prepare release artifacts (tarball, Docker image).  

**Tech Stack:** Bash, Python 3.11, uv, Node.js, Docker, Multipass, Vercel.

---

### Task 1: Verify Onboarding Endpoint Availability

**Objective:** Confirm the onboarding web service is reachable and returns expected status.

**Files:**  
- None (external check)

**Step 1: HTTP GET to onboarding URL**  
Run: `curl -s -o /dev/null -w "%{http_code}" https://onboard.vcoo.dev/health`  
Expected: `200` (or appropriate health endpoint)

**Step 2: Verify OAuth callback endpoint**  
Run: `curl -s -I https://onboard.vcoo.dev/auth/callback | head -1`  
Expected: `HTTP/2 200` or redirect.

**Step 3: Commit any documentation updates if needed**  
*(No code changes expected)*

**Verification:** Both commands return success codes.

---

### Task 2: Run Template Syntax & Structural Tests (Phases 0‑2)

**Objective:** Ensure basic file presence and syntax are correct.

**Files:**  
- `/home/ubuntu/versus/vcoo-template/scripts/vcoo-tester.py`

**Step 1: Run phases 0‑2**  
Run: `cd /home/ubuntu/versus/vcoo-template && python3 scripts/vcoo-tester.py --phase 0 --phase 1 --phase 2`  
Expected: All PASS, no FAIL.

**Step 2: Capture log location**  
Log file: `test-output/logs/T*.log` (verify existence).

**Verification:** Test suite exits with code 0 and reports 0 FAIL.

---

### Task 3: Run Template Integration & Readiness Tests (Phases 3‑6)

**Objective:** Validate that scripts integrate with external services (where credentials available) and that the install process is ready.

**Files:**  
- Same tester script.

**Step 1: Run phases 3‑6**  
Run: `cd /home/ubuntu/versus/vcoo-template && python3 scripts/vcoo-tester.py --phase 3 --phase 4 --phase 5 --phase 6`  
Expected: PASS for applicable tests; any SKIP due to missing credentials is acceptable but should be noted.

**Step 2: Review warnings**  
Check output for WARN lines; document any missing secrets that would affect customer onboarding.

**Verification:** No unexpected FAIL; WARNs logged for missing credentials only.

---

### Task 4: Test Docker‑Based VPS Simulation (Phase 8)

**Objective:** Confirm the template builds and runs correctly in a clean Ubuntu 22.04 Docker image.

**Files:**  
- Dockerfile.test (inside template)  
- `vcoo-tester.py`

**Step 1: Run phase 8**  
Run: `cd /home/ubuntu/versus/vcoo-template && python3 scripts/vcoo-tester.py --phase 8`  
Expected: All PASS.

**Step 2: If Docker not available locally, note requirement**  
If Docker daemon not running, record that this step must be performed in a CI environment with Docker.

**Verification:** Phase 8 completes with 0 FAIL.

---

### Task 5: End‑to‑End Installation Test in a Fresh VM

**Objective:** Verify that the public one‑liner (`curl -fsSL https://install.vcoo.dev | bash`) works on a pristine Ubuntu 22.04 instance.

**Files:**  
- `install.sh` (in onboarding repo)  
- Multipass VM management script (`run_vcoo_test.sh`)

**Step 1: Ensure multipass available**  
Run: `which multipass` (should exist).

**Step 2: Execute the existing VM test script**  
Run: `/home/ubuntu/versus/vcoo-onboarding/run_vcoo_test.sh`  
Expected: Script completes without error, outputting success messages.

**Step 3: If script fails, debug and fix**  
- Examine logs inside VM (multipass exec).  
- Adjust `install.sh` or dependencies as needed.  
- Re‑run until success.

**Verification:** VM test script exits with code 0 and reports “Instalación completada” or similar.

---

### Task 6: Update Documentation & Release Notes

**Objective:** Ensure customers have clear, up‑to‑date instructions.

**Files:**  
- `/home/ubuntu/versus/vcoo-onboarding/README.md`  
- `/home/ubuntu/versus/vcoo-template/README.md`  
- `/home/ubuntu/versus/vcoo-template/SOUL.md`  
- `/home/ubuntu/versus/vcoo-onboarding/CHANGELOG.md` (if exists)

**Step 1: Review and update READMEs**  
- Add any new prerequisites discovered during testing.  
- Clarify the one‑liner usage and expected output.  
- Include troubleshooting tips from WARNs observed.

**Step 2: Update SOUL.md** (soul of the project) with current status and version.

**Step 3: Add entry to CHANGELOG** (or create) summarizing the readiness work.

**Step 4: Commit documentation changes**  
Run: `git add <files> && git commit -m "docs: update readiness info for vX.Y.Z"`  

**Verification:** Docs render correctly (optional: `markdownlint` or similar).

---

### Task 7: Version Bump & Artifact Preparation

**Objective:** Tag the release and prepare distributable packages.

**Files:**  
- `package.json` or version file if exists (otherwise create `VERSION` file).  
- Optionally, create a tarball of the template.

**Step 1: Determine current version** (e.g., from `VERSION` or `README`).  
If none exists, set initial version `1.0.0`.

**Step 2: Bump version** (e.g., to `1.0.1`).  
- Write new version to `VERSION` file.  
- Update any references in READMEs.

**Step 3: Create tarball of template**  
Run: `cd /home/ubuntu/versus && tar -czf vcoo-template-v1.0.1.tar.gz vcoo-template`  

**Step 4: (Optional) Build Docker image for distribution**  
Run: `cd /home/ubuntu/versus/vcoo-template && docker build -t vcoo/template:1.0.1 -f Dockerfile.test .`

**Step 5: Tag git commit**  
Run: `git tag -a v1.0.1 -m "Release v1.0.1 – onboarding & template ready"`  
Push tags: `git push --tags`

**Verification:** Tag exists, tarball created, Docker image built (if Docker available).

---

### Task 8: Final Verification & Sign‑Off

**Objective:** Ensure all preceding tasks passed and artifacts are ready.

**Files:**  
- Test logs from tasks 2‑5.  
- Release artifacts.

**Step 1: Aggregate test results**  
- Collect PASS/FAIL counts from each phase.  
- Ensure zero FAIL in critical phases (0‑6, 8).  

**Step 2: Verify artifact integrity**  
- Check tarball contains expected files (`tar -tzf`).  
- Optionally run template tester inside extracted tarball to confirm self‑contained.

**Step 3: Send readiness report**  
- Output a summary table to the user (or to a designated channel).  

**Verification:** All checks pass; readiness confirmed.

---

## Risks, Tradeoffs, & Open Questions

- **Reliance on external credentials:** Phases 3‑6 may skip tests if OAuth/Google/Trello tokens missing. This is acceptable for distribution; customers will supply their own. Document required env variables.
- **Multipass dependency:** The VM test script uses multipass; if unavailable, we can fall back to manual VM provisioning (e.g., via cloud provider). Note in docs.
- **Docker availability:** Phase 8 requires Docker; CI pipelines should provide it.
- **Versioning:** No existing version file; we introduce `VERSION` to standardize.

## Files Likely to Change

- `vcoo-onboarding/README.md`  
- `vcoo-onboarding/install.sh` (if bugs found)  
- `vcoo-template/README.md`  
- `vcoo-template/SOUL.md`  
- `vcoo-template/VERSION` (new)  
- `vcoo-template/` tarball artifact  
- Git tags

---

**Plan complete and saved.** Ready to execute using subagent-driven-development. Shall I proceed?