#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# VCOO Virtual — Instalador completo
# ═══════════════════════════════════════════════════════════════
# Uso:
#   bash install.sh
# o
#   curl -fsSL https://install.vcoo.dev | bash
#
# Este script:
#   1. Verifica requisitos del sistema
#   2. Instala dependencias (Python, uv, node, etc.)
#   3. Configura Hermes Agent
#   4. Copia skills y scripts VCOO
#   5. Configura integraciones
#   6. Arranca el gateway
# ═══════════════════════════════════════════════════════════════

set -euo pipefail

# ── Colores ─────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; NC='\033[0m'
info()  { echo -e "${BLUE}[VCOO]${NC} $1"; }
ok()    { echo -e "${GREEN}[✓]${NC} $1"; }
warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
err()   { echo -e "${RED}[✗]${NC} $1"; }

# ── Configuración ──────────────────────────────────────────────
VCOO_DIR="$(cd "$(dirname "$0")" && pwd)"
HERMES_HOME="${HOME}/.hermes"
HERMES_SKILLS="${HERMES_HOME}/skills"
HERMES_SCRIPTS="${HERMES_HOME}/scripts/vcoo"

echo ""
echo -e "${BLUE}╔══════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     VCOO Virtual — Instalador            ║${NC}"
echo -e "${BLUE}║     by VERSUS Strategy SL                ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════╝${NC}"
echo ""

# ── 1. Requisitos ──────────────────────────────────────────────
info "Verificando requisitos del sistema..."

OS="$(uname -s)"
ARCH="$(uname -m)"
info "  Sistema: ${OS} ${ARCH}"

# Python
PYTHON="${PYTHON:-python3}"
if ! command -v "$PYTHON" &>/dev/null; then
    err "Python3 no encontrado. Instálalo con: apt install python3"
    exit 1
fi
PYVER=$($PYTHON -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
ok "Python ${PYVER} encontrado"

# curl
if ! command -v curl &>/dev/null; then
    warn "curl no encontrado. Instalando..."
    apt-get update -qq && apt-get install -y -qq curl
fi
ok "curl disponiblee"

# Git
if ! command -v git &>/dev/null; then
    warn "git no encontrado. Instalando..."
    apt-get update -qq && apt-get install -y -qq git
fi
ok "git disponiblee"

# XZ (needed for tar .xz)
if ! command -v xz &>/dev/null; then
    info "XZ no encontrado. Instalando..."
    apt-get update -qq && apt-get install -y -qq xz-utils
fi
ok "xz disponible"

# gettext (provides envsubst)
if ! command -v gettext &>/dev/null; then
    info "gettext no encontrado. Instalando..."
    apt-get update -qq && apt-get install -y -qq gettext
fi
ok "gettext disponiblee"

# ── 2. uv (gestor de paquetes Python rápido) ───────────────────
if ! command -v uv &>/dev/null; then
    info "Instalando uv..."
    curl -fsSL https://astral.sh/uv/install.sh | bash
    export PATH="$HOME/.local/bin:$PATH"
fi
ok "uv $(uv --version 2>/dev/null || echo 'instalado')"

# ── 3. Instalar Hermes Agent + VCOO venv ────────────────────────
if ! command -v hermes &>/dev/null; then
    info "Instalando Hermes Agent..."
    
    # Crear VCOO venv con dependencias de Python (google-api, etc.)
    mkdir -p "${HERMES_SCRIPTS}"
    if [ ! -d "${HERMES_SCRIPTS}/.venv" ]; then
        uv venv --python ${PYTHON} "${HERMES_SCRIPTS}/.venv"
    fi
    
    # Instalar dependencias de VCOO en el venv (NO Hermes Agent)
    uv pip install --python "${HERMES_SCRIPTS}/.venv/bin/python" \
        google-api-python-client google-auth-httplib2 google-auth-oauthlib \
        reportlab weasyprint httpx pyyaml 2>&1 | tail -1
    
    # Instalar Hermes Agent (método oficial: installer de Nous Research)
    # Documentación: https://hermes-agent.nousresearch.com/docs/installation
    if ! command -v hermes &>/dev/null; then
        info "Instalando Hermes Agent (método oficial)..."
        curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash -s -- --skip-setup
        export PATH="$HOME/.local/bin:$PATH"
    fi
    ok "Hermes Agent $(hermes --version 2>/dev/null || echo 'presente')"
else
    ok "Hermes Agent $(hermes --version 2>/dev/null || echo 'presente')"
fi

# ── 4. Configurar Hermes Agent (primera vez) ────────────────────
if [ ! -f "${HERMES_HOME}/config.yaml" ]; then
    info "Configurando Hermes Agent por primera vez..."
    mkdir -p "${HERMES_HOME}"
    
    # Copiar configuración base
    if [ -f "${VCOO_DIR}/config.yaml" ]; then
        cp "${VCOO_DIR}/config.yaml" "${HERMES_HOME}/config.yaml"
        ok "Configuración base copiada"
    fi
    
    # Copiar .env si existe
    if [ -f "${VCOO_DIR}/.env" ]; then
        cp "${VCOO_DIR}/.env" "${HERMES_HOME}/.env"
        chmod 600 "${HERMES_HOME}/.env"
        ok "Variables de entorno copiadas"
    fi
    
    # Copiar SOUL.md
    if [ -f "${VCOO_DIR}/SOUL.md" ]; then
        cp "${VCOO_DIR}/SOUL.md" "${HERMES_HOME}/SOUL.md"
        ok "Personalidad VCOO copiada"
    fi
    
    # Advertir si falta DISCORD_HOME_CHANNEL
    if [ -f "${HERMES_HOME}/.env" ] && ! grep -q '^DISCORD_HOME_CHANNEL=' "${HERMES_HOME}/.env" 2>/dev/null; then
        warn "DISCORD_HOME_CHANNEL no definido en .env — usa el ID del canal de Discord"
        warn "  Ejemplo: DISCORD_HOME_CHANNEL=1519113868411146391"
    fi
else
    info "Hermes Agent ya configurado. Saltando..."
fi

# ── 5. Copiar skills VCOO ──────────────────────────────────────
if [ -d "${VCOO_DIR}/skills" ]; then
    info "Instalando skills VCOO..."
    mkdir -p "${HERMES_SKILLS}/versus-multiagent-orchestration"
    for skill_dir in "${VCOO_DIR}/skills/"*/; do
        skill_name="$(basename "$skill_dir")"
        target="${HERMES_SKILLS}/versus-multiagent-orchestration/${skill_name}"
        if [ -d "$skill_dir" ]; then
            mkdir -p "$target"
            cp -r "$skill_dir"/* "$target/" 2>/dev/null || true
            ok "  Skill: ${skill_name}"
        fi
    done
fi

# ─── 6. Copiar scripts VCOO ─────────────────────────────────────
if [ -d "${VCOO_DIR}/scripts" ]; then
    info "Instalando scripts de integración..."
    mkdir -p "${HERMES_SCRIPTS}"
    for script in "${VCOO_DIR}/scripts/"*.py; do
        if [ -f "$script" ]; then
            # Skip vcoo-tester.py (it already has a portable shebang)
            if [[ "$(basename "$script")" == "vcoo-tester.py" ]]; then
                cp "$script" "${HERMES_SCRIPTS}/"
            else
                # Rewrite shebang to point to VCOO venv
                sed "1s|^#!/usr/bin/env python3|#!${HERMES_SCRIPTS}/.venv/bin/python3|" "$script" > "${HERMES_SCRIPTS}/$(basename "$script")"
            fi
            chmod +x "${HERMES_SCRIPTS}/$(basename "$script")"
        fi
    done
    for script in "${VCOO_DIR}/scripts/"*.sh; do
        if [ -f "$script" ]; then
            cp "$script" "${HERMES_SCRIPTS}/"
            chmod +x "${HERMES_SCRIPTS}/$(basename "$script")"
        fi
    done
    
    # Crear VCOO venv si no existe
    if [ ! -d "${HERMES_SCRIPTS}/.venv" ]; then
        info "Creando entorno virtual VCOO..."
        uv venv "${HERMES_SCRIPTS}/.venv"
        uv pip install --python "${HERMES_SCRIPTS}/.venv/bin/python" \
            google-api-python-client google-auth-httplib2 google-auth-oauthlib \
            reportlab weasyprint httpx pyyaml 2>&1 | tail -1
        ok "Entorno virtual VCOO creado"
    fi
    
    ok "Scripts de integración instalados"
fi

# ── 7. Ejecutar provisionamiento del servidor ──────────────────
if [ -f "${VCOO_DIR}/provision/setup-server.sh" ]; then
    info "Ejecutando provisionamiento del servidor..."
    bash "${VCOO_DIR}/provision/setup-server.sh" || warn "Provisionamiento parcial"
fi

# ── 8. Instalar y activar cron jobs ──────────────────────────────
if command -v hermes &>/dev/null; then
    if [ -d "${VCOO_DIR}/cron-jobs" ]; then
        info "Instalando y activando cron jobs automáticos..."
        mkdir -p "${HERMES_HOME}/cron/job-definitions"
        cp "${VCOO_DIR}/cron-jobs/"*.json "${HERMES_HOME}/cron/job-definitions/" 2>/dev/null || true
        
        # Activar cada cron job a partir de su JSON de definición
        for cronfile in "${HERMES_HOME}/cron/job-definitions/"*.json; do
            [ -f "$cronfile" ] || continue
            name=$(python3 -c "import json; print(json.load(open('$cronfile'))['name'])" 2>/dev/null)
            schedule=$(python3 -c "import json; print(json.load(open('$cronfile'))['schedule'])" 2>/dev/null)
            prompt=$(python3 -c "import json; print(json.load(open('$cronfile'))['prompt'])" 2>/dev/null)
            deliver=$(python3 -c "import json; print(json.load(open('$cronfile')).get('deliver',''))" 2>/dev/null)
            
            if [ -n "$name" ] && [ -n "$schedule" ]; then
                CMD="hermes cron create \"$schedule\" \"$prompt\" --name \"$name\""
                [ -n "$deliver" ] && CMD="$CMD --deliver $deliver"
                
                # No fallar si el cron ya existe (idempotente)
                eval "$CMD" 2>/dev/null && ok "  Cron activado: ${name} (${schedule})" || \
                    warn "  Cron ya existe o no se pudo activar: ${name}"
            fi
        done
        
        ok "Cron jobs configurados y activados"
    fi
fi

# ── 9. Registrar en control plane (si hay PROVISION_TOKEN) ──
# Si AGENT_ID ya está exportado (ej: instalación vía unified installer),
# saltamos el registro API y configuramos directamente.
REGISTERED=false
if [ -n "${AGENT_ID:-}" ]; then
    info "Agente ya registrado (ID: ${AGENT_ID}) — omitiendo registro..."
    REGISTERED=true
elif [ -n "${PROVISION_TOKEN:-}" ] && [ -n "${CONTROL_PLANE_URL:-}" ]; then
    info "Registrando agente en control plane..."
    RESP=$(curl -sS -w "\n%{http_code}" "${CONTROL_PLANE_URL}/register" \
      -H "Content-Type: application/json" \
      -d "{\"token\": \"$PROVISION_TOKEN\", \"info\": {\"hostname\": \"$(hostname)\", \"installer\": \"template-v2\"}}")
    HTTP_CODE=$(echo "$RESP" | tail -1)
    BODY=$(echo "$RESP" | sed '$d')

    if [ "$HTTP_CODE" = "200" ]; then
        AGENT_ID=$(echo "$BODY" | python3 -c "import sys,json; print(json.load(sys.stdin)['agent_id'])" 2>/dev/null || echo "")
        VCOO_ID=$(echo "$BODY" | python3 -c "import sys,json; print(json.load(sys.stdin)['vcoo_id'])" 2>/dev/null || echo "")
        AGENT_TOKEN=$(echo "$BODY" | python3 -c "import sys,json; print(json.load(sys.stdin)['agent_token'])" 2>/dev/null || echo "")
        REGISTERED=true
        ok "Agente registrado en control plane (ID: $AGENT_ID)"
    else
        warn "No se pudo registrar el agente (HTTP $HTTP_CODE). Se puede registrar manualmente desde el panel."
    fi
fi

# ── 9b. Configurar .env y servicios systemd si tenemos agente ──
if $REGISTERED && [ -n "${AGENT_ID:-}" ]; then
    # Guardar/actualizar .env de Hermes
    {
        echo ""
        echo "# VCOO Control Plane (añadido por instalador)"
        echo "VCOO_ID=${VCOO_ID:-}"
        echo "AGENT_ID=${AGENT_ID}"
        echo "AGENT_TOKEN=${AGENT_TOKEN:-}"
    } >> "${HERMES_HOME}/.env"

    # Detectar paths para systemd
    HERMES_PYTHON="${HERMES_PYTHON:-$(which python3 2>/dev/null || echo /usr/bin/python3)}"
    HERMES_BIN="${HERMES_BIN:-$(which hermes 2>/dev/null || echo /usr/local/bin/hermes)}"
    export HERMES_PYTHON HERMES_BIN HERMES_SCRIPTS HERMES_HOME HOME USER

    # Configurar servicios systemd
    info "Configurando servicios systemd..."
    
    # Crear directorio temporal para service files
    SERVICE_TEMP_DIR="$(mktemp -d)"
    
    # Copiar plantillas de servicio
    cp "${VCOO_DIR}/files/systemd/"*.service "${SERVICE_TEMP_DIR}/" 2>/dev/null || true
    
    # Procesar cada servicio
    for service_template in "${SERVICE_TEMP_DIR}"/*.service; do
        [ -f "$service_template" ] || continue
        service_name="$(basename "$service_template")"
        
        # Sustituir variables en la plantilla
        envsubst < "$service_template" | sudo tee "/etc/systemd/system/$service_name" > /dev/null || {
            # Fallback a sed si envsubst no está disponiblee
            sed -e "s|\$HERMES_SCRIPTS|${HERMES_SCRIPTS}|g" \
                -e "s|\$HERMES_HOME|${HERMES_HOME}|g" \
                -e "s|\$HERMES_PYTHON|${HERMES_PYTHON:-/usr/bin/python3}|g" \
                -e "s|\$HERMES_BIN|${HERMES_BIN:-/usr/local/bin/hermes}|g" \
                -e "s|\$HOME|${HOME}|g" \
                -e "s|\$USER|$(whoami)|g" \
                "$service_template" | sudo tee "/etc/systemd/system/$service_name" > /dev/null
        }
        
        ok "Service copiado: $service_name"
    done
    
    # Recargar systemd y activar servicios
    sudo systemctl daemon-reload && ok "Systemd daemon recargado"
    
    sudo systemctl enable --now vcoo-health-reporter.service && \
    ok "Health reporter habilitado e iniciado" || \
    warn "Failed to enable/start health reporter"
    
    sudo systemctl enable --now vcoo-hermes-gateway.service && \
    ok "Hermes gateway habilitado e iniciado" || \
    warn "Failed to enable/start Hermes gateway"
    
    # Limpiar
    rm -rf "$SERVICE_TEMP_DIR"
    
    info "Servicios systemd configurados. Puede verificar con:"
    info "  systemctl status vcoo-health-reporter"
    info "  systemctl status vcoo-hermes-gateway"
fi

# ── 10. Resumen final ──────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║     Instalación completada                ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo "   Próximos pasos:"
echo ""
echo "   1. Configura las integraciones:"
echo "      bash provision/configure-oauth.sh"
echo ""
echo "   2. Edita tu configuración:"
echo "      hermes config edit"
echo ""
echo \"   3. Verifica el estado de los servicios:\"
echo \"      systemctl status vcoo-health-reporter\"
echo \"      systemctl status vcoo-hermes-gateway\"
echo ""
echo "   4. Configura las integraciones:"
echo "      bash provision/configure-oauth.sh"
echo ""
echo "   5. Edita tu configuración:"
echo "      hermes config edit"
echo ""
echo "   6. Envía un mensaje a MAGI desde Discord o Telegram"
echo ""
